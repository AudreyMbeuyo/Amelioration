// Bibliothèque pour les empreintes 
#include <Adafruit_Fingerprint.h>
// Bibliothèque pour la reconnaissance de la carte SD pour la carte arduino
#include <SPI.h>
// Bibliothèque pour l'utilisation de la carte SD 
#include <SD.h>
// Bibliothèque arduino pour faciliter la gestion des fichiers json 
#include <ArduinoJson.h>
// Bibliothèque de gestion du temps à partir du DS1302
#include <DS1302.h>
// Bibliothèque pour la gestion du clavier
#include <Keypad.h>
// Bibliothèque pour permettre la communication avec les périphériques I2C
#include <Wire.h>
// Bibliothèque pour contrôler les écrans I2C avec des fonctions similaires à celle de la librairie LiquidCrystal
#include <LiquidCrystal_I2C.h>


#if (defined(__AVR__) || defined(ESP8266)) && !defined(__AVR_ATmega2560__)
// For UNO and others without hardware serial, we must use software serial...
// pin #2 is IN from sensor (GREEN wire)
// pin #3 is OUT from arduino  (WHITE wire)
// Set up the serial port to use soft0wareserial..

#else
// On Leonardo/M0/etc, others with hardware serial, use hardware serial!
// #0 is green wire, #1 is white
#define mySerial Serial1

#endif

// Structure pour stocker les informations utilisateur
struct UserInfo {
  unsigned long id;  // Matricule
  bool isProf;       // Vrai si c'est un professeur, faux si c'est un étudiant
};

// Définition du capteur d'empreinte
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&mySerial);
// La broche CS pour la carte SD
const int chipSelect = 53;  
// Création d'un fichier json
File jsonFile; 
// Init the DS1302
// I assume you know how to connect the DS1302.
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
DS1302 rtc(22, 24, 26);


// Adressage Matériel
LiquidCrystal_I2C lcd(0x3F, 16, 2);


//Cette variable dit si on est en plein enregistrement afin de savoir si un prof à lancer l"enregistrement
int enrolling = 0;
//L'id du prof qui à lancer l'enregistrement
int teacherId = -1;
//Nombre de prof max
const int TEACHER_NUMBER_MAX = 12;
//Nom du fichier de l'enregistrement en cours
char register_file_path[30] = {0};
//Fichier qui va contenir les enregistrement
File register_file;

#define MATRICULE_ID_FILE_PATH "/idmat.txt" //Chemin vers le fichier des matricule-id
#define CONFIG_FILE_PATH "/config.txt" // Chemin du fichier de configuration
#define TEACHER_ID_MAX 12             // ID max pour les professeurs
#define STUDENT_ID_MAX 127            // ID max pour les étudiants

// Variables globales pour stocker les IDs en mémoire
unsigned int nextTeacherId = 1; // ID du prochain professeur
unsigned int nextStudentId = 13; // ID du prochain étudiant


const int ROW_NUM = 4; //four rows
const int COLUMN_NUM = 4; //four columns
char keys[ROW_NUM][COLUMN_NUM] = {
{'1','2','3', 'A'},
{'4','5','6', 'B'},
{'7','8','9', 'C'},
{'*','0','#', 'D'}
};
 

byte pin_rows[ROW_NUM] = {13, 12, 11, 10}; //connect to the row pinouts of the keypad
byte pin_column[COLUMN_NUM] = {9, 8, 7, 6}; //connect to the column pinouts of the keypad
Keypad keypad = Keypad( makeKeymap(keys), pin_rows, pin_column, ROW_NUM, COLUMN_NUM );
 

//Definition des broches
const int stateBroach = 2;

//Variable pour dire si onnest en enroll ou en verify
int state = 0;


void setup() {
  Serial.begin(9600);
  Serial2.begin(9600);  // Communication avec l'ESP32 via Serial1
  Serial.print("Initialisation de la carte SD...");
  pinMode(stateBroach, INPUT);

  // Initialisation de l'afficheur 
  lcd.init();
  
  // Essayer d'initialiser la carte SD
  if (!SD.begin(chipSelect)) {
    Serial.println("Échec de l'initialisation !");
    return;
  }
  Serial.println("Initialisation réussie !");

  // Vérification de l'existence du fichier de configuration
  if (!SD.exists(CONFIG_FILE_PATH)) {
    Serial.println("Fichier de configuration introuvable. Initialisation avec des valeurs par défaut...");
    writeConfigFile(); // Crée un fichier de configuration avec des valeurs initiales
  }
  // Lecture du fichier de configuration au démarrage
  readConfigFile();

  //Vérifier si le capteur d'empreinte est branché
  initializeFingerprint();
  readFile(MATRICULE_ID_FILE_PATH);

  //Cette broche va permettre de modifier le state pour quitter de enroll à verify
  attachInterrupt(digitalPinToInterrupt(stateBroach), updateAllState, CHANGE);

}

void loop() {
  //If the state is high, it is enrolment
  updateAllState();
  //Serial.println("---------------------i--------------");
  //Serial.print("State is     "); Serial.println(state);
  //Serial.println("-----------------------------------");
  if(state == HIGH){
    enrollFunction();
  }else{
    int recognizedID = verifyFunction();
    if (recognizedID != -1) {
      manageEnrollment(recognizedID);
      //Serial.println("ID recognized and registered");
    }
  }

  lcd.backlight(); 
  // Envoi de message test
  lcd.setCursor(0, 0);
  lcd.print("Je marche bien !");
  lcd.setCursor(0, 1); 
  lcd.print("I2C Serial LCD");

}



//Cette fonction verifie si un enregistrement est en cours i.e si enrolling!=0 et enregistre si necessaire; 
//si l'id scnanné est celui d'un prof on modifie la valeur de enrolling
//La fonction gère différents cas d'enregistrement (en fonction du type d'identifiant et de l'état d'enregistrement).
void manageEnrollment(int id){

  if(id < TEACHER_NUMBER_MAX && enrolling == 0){//On lance l'enregistrement
    teacherId = id;
    //Creatiion du nom du fichier
   snprintf(register_file_path, 30, "%d-%s.txt", teacherId, rtc.getTimeStr());
   removeSpecialCharsButKeepExtension(register_file_path); // Supprimer les caractères spéciaux
    //Creation du fichier
    jsonFile = SD.open(register_file_path, FILE_WRITE);
    if (jsonFile) {
      // Initialisation du fichier avec un tableau JSON vide
      //jsonFile.println("");
      Serial.print("Le fichier a été cree avec succès ");
      Serial.print(register_file_path);
      Serial.println("Et l'enregistrement peut commencer");
      jsonFile.close();
    }else{
      Serial.println("Problème lors de la création du fichier");
    }

    enrolling = 1;
    
  }else if(id < TEACHER_NUMBER_MAX && enrolling == 1){//On ferme l'enregistrement si l'id est égale à celui du teacherId
    if(teacherId == id){//On ferme
      Serial.print("Le fichier était: ");
      Serial.println(register_file_path);
      Serial.println("L'enregistrement est terminé");

      Serial.println("Envoi en cours");
      sendJsonObjects();
      Serial.println("Envoi terminé");

      enrolling = 0;
    }else{//Sinon on ne fait rien

    }

  }else if(id > TEACHER_NUMBER_MAX && enrolling == 0){//On ne fait rien

      Serial.println("C'est un délinquant");

  }else if(id > TEACHER_NUMBER_MAX && enrolling == 1){//C'est un étudiant et on l'enregistre
    Serial.print("Le fichier est: ");
    Serial.println(register_file_path);
    logFingerprintID(id);
  }else{//tout les cas on ne fait rien

  }
}




void logFingerprintID(int id) {
  // Ouvrir le fichier en lecture pour récupérer les données existantes
  jsonFile = SD.open(register_file_path, FILE_WRITE);

  if(!jsonFile){
    Serial.println("Le fichier n'a pas pu être ouvert pour enregistrer l'étudiant");
  }else {
    Serial.println("Le fichier a été ouvert");
    // Créer un document JSON
    StaticJsonDocument<256> doc;
    char jsonString[256] = "";

    // Ajouter un nouvel enregistrement
    doc["id"] = getMatriculeFromId(id);
    // Créer la chaîne de date et heure
    char dateTimeStr[50] = {0};
    getCurrentDateTime(dateTimeStr, 50);
    doc["timestamp"] = dateTimeStr;
    doc["teacherId"] = getMatriculeFromId(teacherId);

    // Sérialiser le document JSON en chaîne
    //String jsonString;
    serializeJson(doc, jsonString);

    // Écrire le JSON dans le fichier
    jsonFile.print(jsonString);
    jsonFile.close();

    Serial.println("ID enregistré avec succès dans data.txt !");
  }

}

void getCurrentDateTime(char *buffer, int bufferSize) {

  char* date = {0};
  date = rtc.getDateStr();
  char* time = {0};
  time = rtc.getTimeStr();

  // Spécifiez la taille du tampon pour snprintf
  sprintf(buffer, "%s", rtc.getDateStr());
  sprintf(buffer, "%s--%s", buffer, rtc.getTimeStr());

  Serial.println(buffer);
}


void sendJsonObjects() {
    // Ouvrir le fichier en lecture
    File jsonFile = SD.open(register_file_path, FILE_READ);
    if (!jsonFile) {
        Serial2.println("Le fichier n'a pas pu être ouvert");
        return;
    }
    
    Serial.println("Le fichier a été ouvert");
    String currentJson = "";  // Stocke un JSON complet en cours de lecture
    char ch;                  // Stocke un caractère lu
    while (jsonFile.available()) {
        ch = jsonFile.read(); // Lire un caractère
        
        currentJson += ch;    // Ajouter le caractère au JSON en cours
        if (ch == '}') {      // Détection de la fin d'un objet JSON
            Serial2.println(currentJson); // Envoyer le JSON à l'ESP32
            Serial.println(currentJson);  // Afficher sur la console
            currentJson = "";
            delay(10000);             // Réinitialiser pour le prochain JSON
        }
    }
    
    jsonFile.close(); // Fermer le fichier
    Serial.println("Lecture terminée.");
}

void removeSpecialCharsButKeepExtension(char* str) {
    // Trouver la position de l'extension .txt
    char* extPos = strstr(str, ".txt");
    
    // Si l'extension est présente
    if (extPos) {
        // Sauvegarder la fin de la chaîne (l'extension .txt)
        char extension[5]; // ".txt" a 4 caractères + '\0'
        strcpy(extension, extPos);
        
        // Boucle pour enlever les caractères spéciaux avant l'extension
        int j = 0;
        for (int i = 0; str[i] != '\0' && &str[i] != extPos; i++) {
            // Si le caractère n'est ni un point (.) ni un tiret (-), on le garde
            if (str[i] != '.' && str[i] != '-' && str[i] != '_' && str[i] != ':') {
                str[j++] = str[i];
            }
        }
        // Terminer la chaîne après avoir supprimé les caractères spéciaux
        str[j] = '\0'; 
        // Ajouter l'extension .txt à la fin de la chaîne
        strcat(str, extension);
    }
}


void updateAllState(){
  state = digitalRead(stateBroach);
}
 


UserInfo getNextId(void) {
  String idStr = "";         // Stocke l'ID comme une chaîne de caractères temporairement
  bool isProf = false;       // Indique si c'est un professeur
  const unsigned long MAX_ID = 990000;  // Limite maximale pour le matricule

  while (true && state == HIGH) {
    char key = keypad.getKey(); // Lecture de la touche pressée

    if (key) { // Si une touche est pressée
      if (key >= '0' && key <= '9') {  // Si c'est un chiffre
        idStr += key;
        Serial.print(key);  // Affiche le caractère saisi pour debug
      } else if (key == 'D') {  // Touche de validation
        Serial.println();  // Aller à la ligne
        break;  // Sortir de la boucle pour valider l'ID
      } else if (key == '*') {  // Touche pour signaler le rôle
        if (idStr == "00000") {  // Code secret pour le professeur
          isProf = true;
          Serial.println("\nVous êtes un professeur. Entrez votre matricule :");
        } else {
          isProf = false;
          Serial.println("\nVous êtes un étudiant. Entrez votre matricule :");
        }
        idStr = ""; // Réinitialiser la chaîne pour saisir le matricule
      }
    }
    delay(100);  // Délai pour éviter les rebonds
  }

  // Convertir la chaîne en entier
  unsigned long id = idStr.toInt();
  if (id <= 0 || id > MAX_ID) {  // Vérification de la validité de l'ID
    Serial.println("ID invalide, entrez un nombre entre 1 et 990000.");
    return {0, false}; // Retourne un ID invalide avec un rôle par défaut
  }

  // Affiche le rôle et le matricule
  if (isProf) {
    Serial.print("Matricule du professeur validé : ");
  } else {
    Serial.print("Matricule de l'étudiant validé : ");
  }
  Serial.println(id);

  // Retourner la structure contenant le matricule et le rôle
  return {id, isProf};
}


/*uint8_t getNextId(void) {
  String idStr = "";  // Stocke l'ID comme une chaîne de caractères temporairement
  int isProf = 0;

  while (true && state == HIGH) {
    char key = keypad.getKey();
    if (key) {  // Si une touche est pressée
      if (key >= '0' && key <= '9') {  // Si c'est un chiffre, on l'ajoute à la chaîne
        idStr += key;
        Serial.print(key);  // Afficher le caractère saisi
      } else if (key == 'D') {  // Touche de validation, ici 'D'
        Serial.println();  // Aller à la ligne
        break;  // Quitte la boucle pour valider l'ID
      } else if (key == '*'){
        if(strcmp(idStr, "00000")){
          isProf = 1;
          Serial.println("Entrée le matricule du prof")
        }
      }
    }
    delay(100);  // Délai pour éviter la détection multiple d'une même touche
  }
  //Si isProf= 1 alors on enregistre en tant que prof
  if(isProf == 1){

  }else{
    
  }
  // Convertir la chaîne en entier
  int id = idStr.toInt();
  if (id <= 0 || id > 127) {  // ID invalide
    Serial.println("ID invalide, entrez un nombre entre 1 et 127.");
    return 0;
  }
  return id;
}
*/
void storeMatricule(){

}

uint8_t enrollFunction(){
  Serial.println("Ready to enroll a fingerprint!");
  Serial.println("Please type in the ID # (from 1 to 127) you want to save this finger as...");
  UserInfo userInfo = getNextId();
  if (userInfo.id == 0) {// ID #0 not allowed, try again!
     return;
  }
  Serial.print("Enrolling ID #");
  Serial.println(userInfo.id);

  int value = -1;
  while (!getFingerprintEnroll(userInfo));
}

int verifyFunction(){
  int value = getFingerprintIDez();
  if(value == -1){
    Serial.println("Finger not Found");
  }
  delay(1000);
  return value;
}

void initializeFingerprint(){
  while (!Serial);  // For Yun/Leo/Micro/Zero/...
  delay(100);
  Serial.println("\n\nAdafruit finger detect test");

  // set the data rate for the sensor serial port
  finger.begin(57600);
  delay(5);
  if (finger.verifyPassword()) {
    Serial.println("Found fingerprint sensor!");
  } else {
    Serial.println("Did not find fingerprint sensor :(");
    while (1) { delay(1); }
  }

  Serial.println(F("Reading sensor parameters"));
  finger.getParameters();
  Serial.print(F("Status: 0x")); Serial.println(finger.status_reg, HEX);
  Serial.print(F("Sys ID: 0x")); Serial.println(finger.system_id, HEX);
  Serial.print(F("Capacity: ")); Serial.println(finger.capacity);
  Serial.print(F("Security level: ")); Serial.println(finger.security_level);
  Serial.print(F("Device address: ")); Serial.println(finger.device_addr, HEX);
  Serial.print(F("Packet len: ")); Serial.println(finger.packet_len);
  Serial.print(F("Baud rate: ")); Serial.println(finger.baud_rate);

  finger.getTemplateCount();

  if (finger.templateCount == 0) {
    Serial.print("Sensor doesn't contain any fingerprint data. Please run the 'enroll' example.");
  }
  else {
    Serial.println("Waiting for valid finger...");
      Serial.print("Sensor contains "); Serial.print(finger.templateCount); Serial.println(" templates");
  }
}

int getFingerprintEnroll( UserInfo userInfo) {

  uint8_t id = 0;

  if(userInfo.isProf == true)
    id = nextTeacherId;
  else
    id = nextStudentId;
  int p = -1;
  Serial.print("Waiting for valid finger to enroll as #"); Serial.println(id);
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image taken");
      break;
    case FINGERPRINT_NOFINGER:
      Serial.print(".");
      break;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      break;
    case FINGERPRINT_IMAGEFAIL:
      Serial.println("Imaging error");
      break;
    default:
      Serial.println("Unknown error");
      break;
    }
    //Si on passe a verify On retourne true
    updateAllState();
    if(state == LOW){
      return true;
    }
  }

  // OK success!

  p = finger.image2Tz(1);
  switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image converted");
      break;
    case FINGERPRINT_IMAGEMESS:
      Serial.println("Image too messy");
      return p;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      return p;
    case FINGERPRINT_FEATUREFAIL:
      Serial.println("Could not find fingerprint features");
      return p;
    case FINGERPRINT_INVALIDIMAGE:
      Serial.println("Could not find fingerprint features");
      return p;
    default:
      Serial.println("Unknown error");
      return p;
  }

  Serial.println("Remove finger");
  delay(2000);
  p = 0;
  while (p != FINGERPRINT_NOFINGER) {
    p = finger.getImage();
    //Si on passe a verify On retourne true
    updateAllState();
    if(state == LOW){
      return true;
    }
  }
  Serial.print("ID "); Serial.println(id);
  p = -1;
  Serial.println("Place same finger again");
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image taken");
      break;
    case FINGERPRINT_NOFINGER:
      Serial.print(".");
      break;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      break;
    case FINGERPRINT_IMAGEFAIL:
      Serial.println("Imaging error");
      break;
    default:
      Serial.println("Unknown error");
      break;
    }

    //Si on passe a verify On retourne true
    updateAllState();
    if(state == LOW){
      return true;
    }
  }

  // OK success!

  p = finger.image2Tz(2);
  switch (p) {
    case FINGERPRINT_OK:
      Serial.println("Image converted");
      break;
    case FINGERPRINT_IMAGEMESS:
      Serial.println("Image too messy");
      return p;
    case FINGERPRINT_PACKETRECIEVEERR:
      Serial.println("Communication error");
      return p;
    case FINGERPRINT_FEATUREFAIL:
      Serial.println("Could not find fingerprint features");
      return p;
    case FINGERPRINT_INVALIDIMAGE:
      Serial.println("Could not find fingerprint features");
      return p;
    default:
      Serial.println("Unknown error");
      return p;
  }

  // OK converted!
  Serial.print("Creating model for #");  Serial.println(id);

  p = finger.createModel();
  if (p == FINGERPRINT_OK) {
    Serial.println("Prints matched!");
  } else if (p == FINGERPRINT_PACKETRECIEVEERR) {
    Serial.println("Communication error");
    return p;
  } else if (p == FINGERPRINT_ENROLLMISMATCH) {
    Serial.println("Fingerprints did not match");
    return p;
  } else {
    Serial.println("Unknown error");
    return p;
  }

  Serial.print("ID "); Serial.println(id);
  p = finger.storeModel(id);
  if (p == FINGERPRINT_OK) {
    Serial.println("Stored!");
    addMatriculeToFile(userInfo, id);
    nextStudentId++;
    nextTeacherId++;
    writeConfigFile();
  } else if (p == FINGERPRINT_PACKETRECIEVEERR) {
    Serial.println("Communication error");
    return p;
  } else if (p == FINGERPRINT_BADLOCATION) {
    Serial.println("Could not store in that location");
    return p;
  } else if (p == FINGERPRINT_FLASHERR) {
    Serial.println("Error writing to flash");
    return p;
  } else {
    Serial.println("Unknown error");
    return p;
  }

  return true;//true si tout se passe
}

int getFingerprintIDez() {
  uint8_t p = finger.getImage();
  if (p != FINGERPRINT_OK)  return -1;

  p = finger.image2Tz();
  if (p != FINGERPRINT_OK)  return -1;

  p = finger.fingerFastSearch();
  if (p != FINGERPRINT_OK)  return -1;

  // found a match!
  Serial.print("Found ID #"); Serial.print(finger.fingerID);
  Serial.print(" with confidence of "); Serial.println(finger.confidence);
  return finger.fingerID;
}

// Fonction pour écrire/créer le fichier de configuration
void writeConfigFile() {
  File configFile = SD.open(CONFIG_FILE_PATH, FILE_WRITE); // Ouvre le fichier en écriture

  if (configFile) {
    // Écrit les IDs sous forme de clé/valeur
    configFile.println(String("nextTeacherId=") + nextTeacherId);
    configFile.println(String("nextStudentId=") + nextStudentId);
    configFile.close();
    Serial.println("Fichier de configuration mis à jour.");
  } else {
    Serial.println("Erreur : Impossible de créer/écrire le fichier de configuration.");
  }
}

// Fonction pour lire le fichier de configuration
void readConfigFile() {
  File configFile = SD.open(CONFIG_FILE_PATH, FILE_READ); // Ouvre le fichier en lecture

  if (configFile) {
    while (configFile.available()) {
      String line = configFile.readStringUntil('\n'); // Lit une ligne à la fois

      // Parse chaque ligne pour extraire les clés et les valeurs
      if (line.startsWith("nextTeacherId=")) {
        nextTeacherId = line.substring(14).toInt(); // Extrait la valeur et la convertit en entier
      } else if (line.startsWith("nextStudentId=")) {
        nextStudentId = line.substring(14).toInt(); // Extrait la valeur et la convertit en entier
      }
    }
    configFile.close();
    Serial.println("Fichier de configuration chargé en mémoire.");
  } else {
    Serial.println("Fichier de configuration introuvable. Création d'un nouveau fichier.");
    writeConfigFile(); // Crée un fichier de configuration par défaut
  }
}

void addMatriculeToFile(UserInfo userInfo, uint8_t id) {
  if (id > 127) {
    Serial.println("Erreur : ID invalide. Il doit être compris entre 0 et 127.");
    return;
  }

  // Ouvrir le fichier en mode écriture (ajout à la fin)
  File file = SD.open(MATRICULE_ID_FILE_PATH, FILE_WRITE);
  if (!file) {
    Serial.println("Erreur : Impossible d'ouvrir le fichier.");
    return;
  }

  // Construire le matricule
  String matricule = String(userInfo.id);
  if (userInfo.isProf) {
    matricule = "M" + matricule; // Ajouter "M" au début pour un professeur
  } else {
    // Ajouter "P" après les deux premiers caractères pour un étudiant
    matricule = matricule.substring(0, 2) + "P" + matricule.substring(2);
  }

  // Écrire dans le fichier
  file.print(id);
  file.print(" ");
  file.println(matricule);

  Serial.print("Matricule ajouté : ");
  Serial.println(matricule);

  file.close();
}

String getMatriculeFromId(uint8_t id) {
  if (id > 127) {
    Serial.println("Erreur : ID invalide. Il doit être compris entre 0 et 127.");
    return "";
  }

  // Ouvrir le fichier en mode lecture
  File file = SD.open(MATRICULE_ID_FILE_PATH, FILE_READ);
  if (!file) {
    Serial.println("Erreur : Impossible d'ouvrir le fichier.");
    return "";
  }

  String matricule = "";
  while (file.available()) {
    String line = file.readStringUntil('\n'); // Lire une ligne
    int spaceIndex = line.indexOf(' ');      // Trouver l'espace
    if (spaceIndex > 0) {
      String idStr = line.substring(0, spaceIndex); // Récupérer l'ID
      if (idStr.toInt() == id) {
        matricule = line.substring(spaceIndex + 1); // Récupérer le matricule
        break;
      }
    }
  }

  file.close();

  if (matricule == "") {
    Serial.println("Matricule non trouvé pour cet ID.");
  }

  return matricule;
}

void readFile(const char* filePath) {
  // Ouvrir le fichier en mode lecture
  File file = SD.open(filePath, FILE_READ);
  
  if (!file) {
    Serial.println("Erreur : Impossible d'ouvrir le fichier.");
    return;
  }

  Serial.println("Lecture du fichier :");
  
  // Lire le fichier ligne par ligne et afficher dans le moniteur série
  while (file.available()) {
    String line = file.readStringUntil('\n'); // Lire une ligne
    Serial.println(line); // Afficher la ligne
  }

  // Fermer le fichier après la lecture
  file.close();
}

void deleteFile(const char* filePath) {
  // Vérifier si le fichier existe avant de tenter de le supprimer
  if (SD.exists(filePath)) {
    // Supprimer le fichier
    if (SD.remove(filePath)) {
      Serial.print("Le fichier ");
      Serial.print(filePath);
      Serial.println(" a été supprimé avec succès.");
    } else {
      Serial.print("Erreur : Impossible de supprimer ");
      Serial.println(filePath);
    }
  } else {
    Serial.print("Erreur : Le fichier ");
    Serial.print(filePath);
    Serial.println(" n'existe pas.");
  }
}

